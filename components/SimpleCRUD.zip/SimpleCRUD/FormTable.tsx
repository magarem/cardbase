import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Box, Button, Card, CardMedia, MenuItem, Select, TextField, Typography } from '@mui/material';
import { useState } from 'react';

function isImage(url: string) {
  if (url) { url = url.split('?')[0]
    return /\.(jpg|jpeg|png|webp|avif|gif|svg)$/.test(url);
  }
}
let a = 0
export default function FormTable({ data, setData, cols, setOpen }: any) {
  const [state, setState] = useState(data);
  const [flag, setFlag] = useState(false);
  
  const handleChange = (e: { target: { name: any; value: any; }; }) => {
    const { name, value } = e.target;
    console.log('name, value: ', name, value);
    // data[name] = value
    setState({...state, [name]:value})
    console.log('data: ', data);
  }
  
  const ShowItem = (value: any) => {
    value = value.value
    if (isImage(value)){ 
      return (
        <Card sx={{ width: 150, maxHeight: 200 }}>
          <CardMedia
            component="img"
            height="100%"
            width="100%"
            image={value}
          />
        </Card>
      )
    }else{
      return (
        <>{value}</>
      )
    }
  }

  const save = () => {
    console.log('state: ', state);
   
    setData(state)
    // setOpen(false)
    setTimeout(() => {
      setOpen(false)
     }, 0)
    
    // setOpen(false)
  }

  if (state) {
    return (
      <TableContainer component={Box}  sx={{
        width: {
          xs: '100%', // theme.breakpoints.up('xs')
          sm: '100%', // theme.breakpoints.up('sm')
          md: 300, // theme.breakpoints.up('md')
          lg: 400, // theme.breakpoints.up('lg')
          xl: 500, // theme.breakpoints.up('xl')
        },
      }}>
        <Table aria-label="a dense table">
          <TableBody>
            {state&&Object.entries(state).filter(([key, value]) => key!=='id').map((row: any, index: number) => (
             <TableRow
                key={row[0]}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                <TableCell component="th" scope="row" >
                    <ShowItem value={cols[index+1].label} />
                </TableCell>
                <TableCell component="th" scope="row" >
                  {cols[index+1].type=='select'&&
                    <Select
                        name={cols[index+1].name} 
                        labelId="demo-simple-select-label"
                        id="demo-simple-select"
                        value={state[cols[index+1].name]}
                        onChange={handleChange}
                      >
                      {cols[index+1].options.map((i: any)=>{
                        return (
                          <MenuItem key={i[0]} value={i[0]}>{i[1]}</MenuItem>
                        )
                      })}
                    </Select>
                  }
                  {cols[index+1].type!=='select'&&
                  <>
                    <TextField name={cols[index+1].name} value={state[cols[index+1].name]} onChange={handleChange}/>
                  
                  </>
                  }
                </TableCell>
              </TableRow>
            ))}
             <TableRow>
                <TableCell align="right" colSpan={2} component="th" scope="row" >
                  <Button variant="contained" onClick={()=>{save()}} sx={{marginRight:1}}>Save</Button>
                  <Button variant="contained" onClick={()=>setOpen(false)}>Cancelar</Button>
                </TableCell>
             </TableRow>
          </TableBody>
        </Table>
      </TableContainer>
    )
  }else{
    return null
  }
}


