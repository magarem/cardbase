import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Box, Button, IconButton, Typography } from '@mui/material';
import linkifyHtml from "linkify-html";
import Modal from "../Modal";
import FormTable from "./FormTable"
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddCircleIcon from '@mui/icons-material/AddCircle';

const rows: any = [];
let reset = (obj: any) => {
    Object.keys(obj).map(key => {
      if (obj[key] instanceof Array) obj[key] = []
      else obj[key] = ''
    })
  }
export default function SimpleTable(props: any) {

    // let fontData = props.fontData
    // let cols = fontData.cols
    // let rows = fontData.rows
    // let table = fontData.split('.').pop()
    // let setRows = 'auxFunc_setSystemStateRows'

    const [open, setOpen] = React.useState(false);
    const [data, setData] = React.useState<any>({})
    const [selectedIndex, setSelectedIndex] = React.useState<number>(0)
   
    console.log('props.rows: ', props);

    let a: any = {}

    const selectedRow = async (value: any) => {
        console.log('value: ', value);
        console.log('props.rows: ', props.rows);
        setData({...value})
        setTimeout(() => {
            setOpen(true)
           }, 0)
    }
    
    const deleteRow = (value: any) => {
        if (confirm('Confirma exclusão de registro?')){
            let r = props.rows.filter((item: any) => item !== value)
            console.log('props.rows: ', props.rows);
            console.log('r: ', r);
            // props.setRows(r) 
            props.setRows(props.table, [...r])
            setData({})
        }
        
    }

    const showRow = (str: string) => {
        return String(str).substring(0,200)
    } 

    const bodyHtmlGen = (str: string) => {
        return linkifyHtml(str.replace(/\n/g, "<br />"), {
            target: {
            url: "_blank"}})
    }

    const ShowDataFromSelectBox = ({value, options}: any) => {
        let ret = options.find((x: any)=>x[0] == value)
        return <>{ret?.length>0?ret[1]:''}</>
    }


    const add = () => {
        let x = Date.now().toString(36) + Math.random().toString(36).substring(2);
        let clone = {...props.rows[0]}
        console.log('props.rows[0]: ', props.rows[0]);
        reset(clone)
        console.log('clone: ', clone);
        clone.id = x
        setTimeout(() => {
            setData({...clone})
           }, 0)
        setTimeout(() => {
            setOpen(true)
            
           }, 100)
    }

    React.useEffect(()=>{

        // let data_ = Object.fromEntries(
        //     Object.entries(data).slice(1)
        // )
        let data_ = {...data}
        delete data_.id
        let isFormEmpty = Object.values(data_).join().replaceAll(',','').length==0
        
        console.log('isFormEmpty: ', isFormEmpty);
        
        if (!isFormEmpty) {
            let index = props.rows.findIndex((x: any)=>x.id==data.id)
            if (index>-1){
                //Edition
                let cc = props.rows
                cc[index] = data
                setTimeout(() => {
                  console.log('props.table, [...cc]: ', props.table, [...cc]);
                  props.setRows(props.table, [...cc])
                }, 10)
            }else{
                //New record created
                //Edition
                let cc = props.rows
                cc.push(data)
                props.setRows(props.table, [...cc])
            }
            console.log('Data changed in component', data);
        }
    },[data])

    return (
        <>
            <Modal 
                open={open} 
                setOpen={setOpen} 
                title="Dados"
                >
                <FormTable cols={props.cols} setOpen={setOpen} data={data} setData={setData}/>
            </Modal>
            
            <TableContainer style={{minWidth: 650, overflowX: 'auto'}} component={Paper}>
            <Table aria-label="simple table">
                <TableHead>
                <TableRow>
                    <TableCell size='small'align='center' component="th" scope="row"><b>Ações</b></TableCell>
                    {props.cols&&props.cols.filter((col: any) => !col.hidden).map((col: any)=>(
                        <TableCell component="th" key={Date.now().toString(36) + Math.random().toString(36).substring(2)}><b>{col.label}</b></TableCell>
                    ))}
                    {/* <TableCell size='small' component="th" scope="row"></TableCell> */}
                </TableRow>
                </TableHead>
                <TableBody>
                {props.rows&&props.rows.map((row: any, index: number) => (
                    <TableRow
                    key={row.id}
                    // sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                    > 
                    <TableCell width={120} component="th" scope="row">
                        <IconButton onClick={()=>selectedRow(row)}><EditIcon/></IconButton>
                        <IconButton onClick={()=>deleteRow(row)}><DeleteIcon/></IconButton>
                    </TableCell>
                    {props.cols.filter((col: any) => !col.hidden).map((col:any, index2:any)=>(
                        <TableCell key={Date.now().toString(36) + Math.random().toString(36).substring(2)} component="th" scope="row">
                            {(col.type === "string")&&<>
                             <Typography variant="body1" dangerouslySetInnerHTML={{ __html: bodyHtmlGen(showRow(row[col.name])) }}/>
                            </>
                               
                            }
                            {(col.type === "select")&&
                            <ShowDataFromSelectBox  value={row[col.name]} options={col.options}/>
                            }
                        </TableCell>
                    ))}
                    </TableRow>
                ))}
                 <TableRow>
                        <TableCell colSpan={props.cols.length}> 
                            <Button variant="contained" onClick={()=>add()} startIcon={<AddCircleIcon />}>
                                Novo registro
                            </Button>
                        </TableCell>
                    </TableRow>
                </TableBody>
            </Table>
            </TableContainer><br/>
           
        </>
    );
}
