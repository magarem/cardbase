# Authentication in Next.js with Firebase

[click here for a video tutorial](https://www.youtube.com/watch?v=ZmpO65DhRN0)
