import { route } from 'next/dist/server/router'
import React, { useEffect, useState } from 'react'
import { useAuth } from '../context/AuthContext'
import { useRouter } from 'next/router'
import { Copyright } from '@material-ui/icons'
import { CssBaseline, Box, Typography, TextField, Button, Container, Dialog, DialogContent, DialogContentText, DialogTitle, FormControl, InputLabel, MenuItem, Select } from '@mui/material'
import Link from '@mui/material/Link';
import AlertDialog from '../components/AlertDialog'
import CardDataService from '../services/services'
import { displayName } from 'react-quill'

function CopyrightFooter(props: any) {
  return (
    <Typography variant="body2" color="text.secondary" align="center" {...props}>
      {'Copyright © '}
      <Link color="inherit" href="">
        ZenSite
      </Link>{' '}
      {new Date().getFullYear()}
      {'.'}
    </Typography>
  );
}


const Signup = () => {
  const router = useRouter()
  const { user, registerUser, login, logout } = useAuth()
  console.log({user});
  if (user) logout()
  const fields = [
    {name:'email', label: 'e-mail', type: 'email', autofocus: true}, 
    {name:'password', label: 'Senha', type: 'password',  minLength: 6},
    {name:'confirmpassword', label: 'Confirma Senha', type: 'password',  minLength: 6, autofocus: false,  check: 'password'},
   
    ]

  const map1 = new Map()
  map1.set('email', {label: 'e-mail', type: 'email', autofocus: true})
  map1.set('password', {label: 'Senha', type: 'password',  minLength: 6})
  map1.set('confirmpassword', {label: 'Confirma Senha', type: 'password',  minLength: 6, autofocus: false,  check: 'password'})
  map1.set('displayName', {label: 'Nome de usuário', type: '', autofocus: false})


  map1.forEach((value, key) => {
    console.log(map1.get(key).check);
  });


  console.log(user)
  const [flgErrorDialog, setFlgErrorDialog] = useState(false)
  const formBegin = {}
  const [data, setData] = useState(formBegin)
  const [open, setOpen] = React.useState(false);
  const [buttonCreateAccount, setButtonCreateAccount] = React.useState(false);

  
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };
  useEffect(() => {
    if (location.href !== location.href.replace(/^[^.]+\./g, "")){
      const url1 = window.location.protocol + '//' + window.location.origin.replace(/^[^.]+\./g, "")
      console.log( url1 + '/signup');
      location.href = url1 + '/signup'
    }
  },[])

  const handleSignup = async (e: any) => {
    e.preventDefault()
    setButtonCreateAccount(true)
    // CardDataService.check_displayName(data.displayName)
    // const et1 = await CardDataService.check_displayName(data.displayName)
    // console.log(et1);
    // if (!et1) {
    //     let error = false
    //     console.log("esse user name está disponível");
    //     console.log(data);
    //     fields.map((item) => {
    //       if (item.minLength){
    //         if (data[item.name].length<item.minLength) {
    //           alert('Erro no campo ' + item.label + ', mínimo de ' + item.minLength + ' dígitos')
    //           error = true
    //         }
    //         if (item.check){
    //           if (data[item.name] !== data[item.check]) {
    //             alert('Erro: Os campos ' + item.label + ' e ' + item.check + ' não conferem')
    //           }
    //         }
    //       }
    //     })
        
    //     if (!error){
    //       const user = await registerUser(data.email, data.displayName, data.password)
    //       console.log({user})
    //       if (!user){
    //         alert('Erro')
    //         setButtonCreateAccount(false)
    //       }
    //       if (user) {
    //         console.log("usuário criado com sucesso", user);

    //         CardDataService.addUserSettings(user.displayName, {key: 'home', value: 'home'})
    //           .then((x) => {
    //             console.log("Created new user settings item successfully!");
    //             console.log(x)
    //           })
    //           .catch((e) => {
    //             console.log(e);
    //           });
    //         // login(data.email, data.password).then((ret: { user: { displayName: string } })=>{
    //         //   console.log(ret.user.displayName);
    //         //   // router.push(ret.user.displayName + '/home')
    //         //   const url1 = window.location.protocol + '//' + ret.user.displayName + '.' + window.location.hostname + ':' + location.port
    //         //   console.log( url1 + '/home');
    //         //   location.href = url1 + '/home'
    //         // })
    //       }else{
    //         setFlgErrorDialog(true)
    //         setTimeout(() => {
    //           setFlgErrorDialog(false)
    //         }, 3000)
    //       }
        
    //   }
    // }else{
    //   alert('Esse nome de usuário já existe')
    //   setButtonCreateAccount(false)
    // }
  }

  const onchange_ = (e: any) => {
    console.log(e);
    
    setData({
      ...data, [e]: e.target.value
    })
  }

  function handleChange(event) {
    setData({
      ...data, [event.target.name]: event.target.value
    })
    console.log(data);
  }

  return (
      <Container component="main" maxWidth="xs">
      <CssBaseline />
      <Dialog
        open={open}
        onClose={handleClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          {"Defina um nome de usuário"}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
                    <FormControl fullWidth>
                      {/* <InputLabel id="demo-simple-select-label">Pasta</InputLabel> */}
                      {/* <TextField  
           
            margin="normal"
            required
            fullWidth
            id='displayName'
            label='Nome de usuário'
            name='displayName'
            autoFocus={true}
            onChange={handleChange}
            value={data.displayName}
            /> */}
                    </FormControl>
          </DialogContentText>
        </DialogContent>
      </Dialog>
      <AlertDialog time img="" title="Erro" body="Esse e-mail ou nome do usuário já existente" mostra={flgErrorDialog} setMostra={setFlgErrorDialog}/>
      <Box sx={{
          marginTop: 8,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
      }}>
        <Typography component="h1" variant="h5" mt={4}>
          Registro
        </Typography>
        <Box component="form" onSubmit={handleSignup} noValidate sx={{ mt: 1 }}>
         {fields.map((item, i)=>{
           return (
            <TextField  
            key={item.name}
            type={item.type}
            margin="normal"
            autoComplete="new-password"
            required
            fullWidth
            id={item.name}
            label={item.label}
            name={item.name}
            autoFocus={item.autofocus==true}
            onChange={handleChange}
            value={data[item.name]}
            />
            )
         })}

          {/* <TextField
            
            margin="normal"
            required
            fullWidth
            id="teste2"
            label="teste2"
            name="teste2"
            autoFocus
            onChange={(e: any) =>
              setData({
                ...data,
                teste2: e.target.value,
              })
            }
            value={data.teste2}
          />




           <TextField
           
            margin="normal"
            required
            fullWidth
            id="email"
            label="Email"
            name="email"
            autoFocus
            onChange={(e: any) =>
              setData({
                ...data,
                email: e.target.value,
              })
            }
            value={data.email}
          />
           <TextField
            variant="outlined" 
            margin="normal"
            required
            fullWidth
            id="displayName"
            label="Usuário"
            name="displayName"
            
            onChange={(e: any) =>
              setData({
                ...data,
                displayName: e.target.value,
              })
            }
            value={data.displayName}
          />


          <TextField
           
            margin="normal"
            required
            fullWidth
            name="password"
            label="Senha"
            type="password"
            id="password"
           
            onChange={(e: any) =>
              setData({
                ...data,
                password: e.target.value,
              })
            }
            value={data.password}
          /> */}
          <Button
            disabled={buttonCreateAccount}
            color="success"
            type="submit"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}>
            Criar minha conta
          </Button>
          {/* <Typography align="center">
                  ou
          </Typography> */}<br/><br/>
          <Typography align="center">
            <Link href="/login" variant="body2">Já tenho uma conta</Link>
          </Typography>
          {/* <Button
            color="info"
            fullWidth
            variant="contained"
            sx={{ mt: 3, mb: 2 }}>
            Já tenho uma conta
          </Button> */}
          
        </Box>
      </Box>
      <CopyrightFooter sx={{ mt: 8, mb: 4 }} />
    </Container>
  )
}

export default Signup
