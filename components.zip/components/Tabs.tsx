import * as React from 'react';
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';
import { Children, cloneElement } from "react";
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function TabPanel(props: TabPanelProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          <Typography component={'span'}>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

function a11yProps(index: number) {
  return {
    id: `simple-tab-${index}`,
    'aria-controls': `simple-tabpanel-${index}`,
  };
}

export default function BasicTabs({children}: any) {
  const [value, setValue] = React.useState(0);
  const arrayChildren = Children.toArray(children);

  console.log(children);
  
  const handleChange = (event: React.SyntheticEvent, newValue: number) => {
    setValue(newValue);
  };

  return (
    <Box sx={{ width: '100%', padding: 0, margin: 0 }}>
      <Box sx={{ borderBottom: 1, borderColor: 'divider', margin: 0 }}>
        <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
          <Tab label="Texto" {...a11yProps(0)} />
          <Tab label="Mídia" {...a11yProps(1)} />
          <Tab label="Anexo" {...a11yProps(2)} />
          <Tab label="Info" {...a11yProps(3)} />
        </Tabs>
      </Box>
      <div>
        {Children.map(arrayChildren, (child, i) => {
            if (React.isValidElement(child)) {
              if (child.props['data-tab']=='tab1'){
                return (
                  <TabPanel value={value} index={0} >
                    <Box sx={{ marginTop: -1, marginLeft: -3,  marginRight: -3}}>
                      {child}
                    </Box>
                  </TabPanel>
                )
              }
                if (child.props['data-tab']=='tab2'){
                    return (
                      <TabPanel value={value} index={1} >
                        <Box sx={{ marginTop: 0, marginLeft: -3,  marginRight: -3}}>
                          {child}
                        </Box>
                    </TabPanel>
                    )
                }
                if (child.props['data-tab']=='tab3'){
                  return (
                      <TabPanel value={value} index={2}>
                        <Box sx={{ marginTop: 0, marginLeft: -3,  marginRight: -3}}>
                          {child}
                        </Box>
                      </TabPanel>
                  )
                }
                if (child.props['data-tab']=='tab4'){
                    return (
                      <TabPanel value={value} index={3} >
                        <Box sx={{ marginTop: 0, marginLeft: -3,  marginRight: -3}}>
                          {child}
                        </Box>
                    </TabPanel>
                    )
                } 
                
            }
        })}
      </div>
    </Box>
  );
}