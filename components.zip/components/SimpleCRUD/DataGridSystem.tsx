import SimpleTable from './SimpleTable'
import React, { useEffect } from 'react'
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Typography from '@mui/material/Typography';
import Box from '@mui/material/Box';

interface TabPanelProps {
    children?: React.ReactNode;
    index: number;
    value: number;
  }
  
  function TabPanel(props: TabPanelProps) {
    const { children, value, index, ...other } = props;
  
    return (
      <div
        role="tabpanel"
        hidden={value !== index}
        id={`simple-tabpanel-${index}`}
        aria-labelledby={`simple-tab-${index}`}
        {...other}
      >
        {value === index && (
          <Box sx={{ p: 3 }}>
            {children}
          </Box>
        )}
      </div>
    );
  }
  
  function a11yProps(index: number) {
    return {
      id: `simple-tab-${index}`,
      'aria-controls': `simple-tabpanel-${index}`,
    };
  }


const DataGridSystem = ({user, system, ret, setRet}: any) => {

    const [value, setValue] = React.useState(0);
    const [systemState, setSystemState] = React.useState<any>(system)
    const [tableDesity, setTableDesity] = React.useState<boolean>(true)
    const [tteste, setTteste] = React.useState<any>([])

    const handleChange = (event: React.SyntheticEvent, newValue: number) => {
      setValue(newValue);
    };

    const handleRefresh = () => {
        system.rules?.map((i: any)=>{
            let ret = systemState.tables[i.tabela_destino].cols.map((x: any)=>(
                (x.name == i.tabela_destino_field)
                    ?{...x, options: systemState.tables[i.tabela_origem].rows?.map((a: { id: any; nome: any }) => [a[i.tabela_origem_id], a[i.tabela_origem_valor]])}
                    :x
              )
            )
            system = {...systemState}
            system.tables[i.tabela_destino].cols = ret
            setSystemState({...system })
        })
    }

    // const testeRows = (table: any, value: any) => {

    // })
    const auxFunc_setSystemStateRows = (table: any, value: any) => {
        let cloneState = {...systemState}
        cloneState.tables[table].rows = value
        console.log(Object.entries(cloneState.tables));
        let g: any = []
        let ret = Object.entries(cloneState.tables).map((x)=>{
            // console.log(Object.values(x));
            g.push([Object.values(x)[0], Object.values(x)[1].rows])
        })
        const obj = Object.fromEntries(g);
        console.log('obj: ', obj);
        setSystemState({...cloneState})
        setRet(obj)
        handleRefresh()
    }
    let t:any = []
    // useEffect(()=>{
      
    //   console.log(systemState.tables);
    //   Object.entries(systemState.tables).map((i: any, index: number)=>{
    //     console.log(i[1]);
    //     console.log(i[1].rows);
    //     t.push(i[1].rows)
    //   })
    //   console.log(t);
    //   setTteste(t)
    // },[systemState])
    
    useEffect(()=>{
        
       
        handleRefresh()
    },[])


   

    if (true){
        return (
            <Box sx={{ width: '100%', marginBottom:-2 }}>
                <Box sx={{ borderBottom: 1, borderColor: 'divider' }}>
                <Tabs value={value} onChange={handleChange} aria-label="basic tabs example">
                    {Object.values(systemState.tables).map((i: any)=>
                        (<Tab key={i.label} label={i.label} {...a11yProps(0)} />))
                    }
                </Tabs>
                </Box>
                {Object.entries(systemState.tables).map((i: any, index: number)=>(
                    <TabPanel key={i[0]} value={value} index={index}>
                        <SimpleTable 
                            user={user}
                            tableDesity={tableDesity}
                            setTableDesity={setTableDesity}
                            title={i[1].label}
                            cols={i[1].cols} 
                            rows={i[1].rows} 
                            table={i[0]} 
                            setRows={auxFunc_setSystemStateRows} 
                           />
                    </TabPanel>)
                )}
         </Box>
        )
    }
}

export default DataGridSystem
