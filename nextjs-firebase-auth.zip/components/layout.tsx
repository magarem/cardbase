
import * as React from 'react';
import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import Button from '@mui/material/Button';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import InboxIcon from '@mui/icons-material/MoveToInbox';
import MailIcon from '@mui/icons-material/Mail';
import Navbar from './Navbar'
import CardDataService from "../services/services";
import { useAuth } from '../context/AuthContext'
import { useRouter } from 'next/router';
import FolderIcon from '@mui/icons-material/Folder';

type Anchor = 'top' | 'left' | 'bottom' | 'right';

export default function Layout({ children }) {
  const router = useRouter()
  const { user } = useAuth()
  const [stateFolder, setStateFolder] = React.useState([{key: String, value: String}])
  const [state, setState] = React.useState({
    top: false,
    left: false,
    bottom: false,
    right: false,
  });
  function golink(key: StringConstructor, value: StringConstructor): void {
    console.log({key, value});
    const url = window.location.origin + '/' + value + '/list'
    window.location.href = url
  }

  React.useEffect(() => {
    // setState({cardSession: folder})
    if (user){
      const data = CardDataService.readById(user.displayName, "settings").then((data: any) => {
        setStateFolder(Object.values(data))
        // const folder_key = Object.values(data).filter(item => item.value == folder)[0].key
        // console.log(folder_key)
        // setState({cardSession: folder_key})
      })
    }

  }, [])

  const toggleDrawer =
    (anchor: Anchor, open: boolean) =>
    (event: React.KeyboardEvent | React.MouseEvent) => {
      if (
        event.type === 'keydown' &&
        ((event as React.KeyboardEvent).key === 'Tab' ||
          (event as React.KeyboardEvent).key === 'Shift')
      ) {
        return;
      }

      setState({ ...state, [anchor]: open });
    };

  const list = (anchor: Anchor) => (
    <Box
      sx={{ width: anchor === 'top' || anchor === 'bottom' ? 'auto' : 250 }}
      role="presentation"
      onClick={toggleDrawer(anchor, false)}
      onKeyDown={toggleDrawer(anchor, false)}
    >
      <List>
        <ListItem>
          {/* <ListItemButton> */}
            <ListItemText primary="Pastas" />
          {/* </ListItemButton> */}
        </ListItem>
        {stateFolder.map((item, index) => (
          <ListItem key={item.value} disablePadding onClick={()=>golink(item.key, item.value)}>
            <ListItemButton>
              <ListItemIcon>
                <FolderIcon />
                {/* {index % 2 === 0 ? <InboxIcon /> : <MailIcon />} */}
              </ListItemIcon>
              <ListItemText primary={item.value} />
            </ListItemButton>
          </ListItem>
        ))}
      </List>
      <Divider />
      {/* <List>
        {stateFolder.map((text, index) => (
          <ListItem key={text} disablePadding>
            <ListItemButton>
              <ListItemIcon>
                {index % 2 === 0 ? <InboxIcon /> : <MailIcon />}
              </ListItemIcon>
              <ListItemText primary={text} />
            </ListItemButton>
          </ListItem>
        ))}
      </List> */}
    </Box>
  );

  return (
    <div>
      {(['left'] as const).map((anchor) => (
        <React.Fragment key={anchor}>
          <Drawer
            anchor={anchor}
            open={state[anchor]}
            onClose={toggleDrawer(anchor, false)}
          >
            {list(anchor)}
          </Drawer>
          <Navbar toggleDrawer={toggleDrawer}/>
          <main>{children}</main>
        </React.Fragment>
      ))}
    </div>
  );
}


