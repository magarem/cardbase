import type { NextPage } from 'next'
import { useState } from 'react'
import SimpleTable from '../components/SimpleTable'
import FormTable from "../components/FormTable"
import { Button } from '@mui/material'

const data_cols: any = [
    {name:'id', label:'id', hidden: true}, 
    {name:'nome', label:'nome'}, 
    {name:'email', label:'email'}, 
    {name:'tel', label:'Telefone'}]

const data_rows: any = [
    {id: '0', nome:'Maguete', email:'contato@teste.com', tel: '23232323'}, 
    {id: '1', nome:'Fidelis', email:'ninja@teste.com', tel: '23555232323'},
    {id: '2', nome:'Top', email:'top@teste.com', tel: '6666323'}
]

let reset = (obj: any) => {
    Object.keys(obj).map(key => {
      if (obj[key] instanceof Array) obj[key] = []
      else obj[key] = ''
    })
  }

let firstRender = true

const AccontUsersAdmin: NextPage = () => {
   
    const [rows, setRows] = useState<any[]>(data_rows);
    const [data, setData] = useState<any>({})
   
    const selectedRow = (value: any) => {
        let index = rows.findIndex((x: any)=>x.id==value)
        setData(value)
    }
    
    const deleteRow = (value: any) => {
        let r = rows.filter((item: any) => item !== value)
        setRows([...r])
        setData({})
    }
   
    const add = () => {
        console.log(2);
        let x = Date.now().toString(36) + Math.random().toString(36).substring(2);
        let clone = {...rows[0]}
        reset(clone)
        console.log('clone: ', clone);
        clone.id = x
        setData(clone)
    }

    const save = () => {
        let r = rows.filter((item: any) => item.id == data.id)
        if (r.length){
            let index = rows.findIndex((x: any)=>x.id==data.id)
            rows[index] = data
        }else{
            rows.push(data)
        }
        setRows([...rows])
        setData({})
    }

    if (firstRender){
        firstRender = false
        data_cols.push({name: selectedRow, label:'Edit'}, {name: deleteRow, label:'Del'})
    }

    return (
        <div>
            <Button onClick={()=>add()}>Add</Button>
            <SimpleTable cols={data_cols} rows={rows}/>
            <br/>
            {data&&<FormTable data={data}/>}
            <Button onClick={()=>save()}>Save</Button>
        </div>
    )
}

export default AccontUsersAdmin
