import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { Button, Typography } from '@mui/material';
import linkifyHtml from "linkify-html";

const rows: any = [];

export default function BasicTable(props: any) {
    console.log('props.rows: ', props);

    let a: any = {}

    const callFunction = (func: Function, value: any) => {
        console.log('func: ', func);
        a = {func1: func}
        a.func1(value)
    }

    const showRow = (str: string) => {
        return String(str).substring(0,200)
    } 

    const bodyHtmlGen = (str: string) => {
        return linkifyHtml(str.replace(/\n/g, "<br />"), {
            target: {
            url: "_blank"}})
    }

    return (
        <TableContainer style={{width: '100%', overflowX: 'auto'}} component={Paper}>
        <Table aria-label="simple table">
            <TableHead>
            <TableRow>
                {props.cols.filter((col: any) => !col.hidden).map((col: any)=>(
                    <TableCell component="th" key={col.name}>{col.label}</TableCell>
                ))}
            </TableRow>
            </TableHead>
            <TableBody>
            {props.rows.map((row: any, index: number) => (
                <TableRow
                key={row.id}
                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
                >
                    {props.cols.filter((col: any) => !col.hidden).map((col:any, index2:any)=>(
                        <TableCell key={col.name + index2} component="th" scope="row">
                            {(typeof row[col.name] === "undefined")?
                                <Button key={col.name + index2+ '_'} onClick={()=>callFunction(col.name, row)}>{col.label}</Button>
                                :
                                <Typography key={col.name + index2 + '_'} variant="body1" dangerouslySetInnerHTML={{ __html: bodyHtmlGen(showRow(row[col.name])) }}/>
                            }
                        </TableCell>
                    ))}
                    
                </TableRow>
            ))}
            </TableBody>
        </Table>
        </TableContainer>
    );
}
